"""
Enhanced Dashboard - Quality Intelligence Engine V3.0
Modern analytics with AI-powered insights
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import numpy as np

st.set_page_config(page_title="Dashboard", page_icon="📊", layout="wide")

# Enhanced CSS with animations
st.markdown("""
<style>
    /* Animated gradient background */
    .stApp {
        background: linear-gradient(-45deg, #0a0e1a, #1a0a2e, #16213e, #0f3460);
        background-size: 400% 400%;
        animation: gradient 15s ease infinite;
    }
    
    @keyframes gradient {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    
    /* Glowing metrics */
    [data-testid="stMetricValue"] {
        font-size: 2.5rem;
        font-weight: bold;
        background: linear-gradient(90deg, #00f5ff, #ff00ff);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 0 0 30px rgba(0, 245, 255, 0.5);
        animation: glow 2s ease-in-out infinite alternate;
    }
    
    @keyframes glow {
        from { filter: brightness(1); }
        to { filter: brightness(1.3); }
    }
    
    /* Glassmorphism cards */
    .metric-card {
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 16px;
        padding: 1.5rem;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-5px);
        border-color: rgba(0, 245, 255, 0.5);
        box-shadow: 0 12px 40px rgba(0, 245, 255, 0.3);
    }
    
    /* Neon headers */
    h1, h2, h3 {
        color: #00f5ff !important;
        text-shadow: 0 0 20px rgba(0, 245, 255, 0.5),
                     0 0 40px rgba(0, 245, 255, 0.3);
        font-weight: 800;
    }
    
    /* Enhanced buttons */
    .stButton>button {
        background: linear-gradient(90deg, #00f5ff, #ff00ff);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 0.75rem 2rem;
        font-weight: bold;
        box-shadow: 0 4px 20px rgba(0, 245, 255, 0.4);
        transition: all 0.3s ease;
    }
    
    .stButton>button:hover {
        transform: scale(1.05);
        box-shadow: 0 6px 30px rgba(0, 245, 255, 0.6);
    }
    
    /* Alert boxes */
    .stAlert {
        background: rgba(255, 100, 100, 0.1);
        border-left: 4px solid #ff00ff;
        border-radius: 8px;
    }
</style>
""", unsafe_allow_html=True)

# Title with gradient animation
st.markdown("""
<h1 style='
    font-size: 3.5rem;
    text-align: center;
    background: linear-gradient(90deg, #00f5ff 0%, #ff00ff 50%, #00f5ff 100%);
    background-size: 200% auto;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: shimmer 3s linear infinite;
    margin-bottom: 0;
'>
🎯 Quality Intelligence Dashboard
</h1>
<p style='text-align: center; color: #888; font-size: 1.3rem; margin-top: 0;'>
Real-time Analytics • AI-Powered Insights • Performance Monitoring
</p>
""", unsafe_allow_html=True)

st.markdown("---")

# Sidebar with enhanced controls
with st.sidebar:
    st.markdown("### ⚙️ Dashboard Controls")
    
    # Date range selector
    date_range = st.selectbox(
        "📅 Time Period",
        ["Last 24 Hours", "Last 7 Days", "Last 30 Days", "Last Quarter", "Custom Range"]
    )
    
    if date_range == "Custom Range":
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input("Start Date")
        with col2:
            end_date = st.date_input("End Date")
    
    # Metric selector
    st.markdown("### 📊 Metrics to Display")
    show_quality = st.checkbox("Quality Score", value=True)
    show_compliance = st.checkbox("Compliance Rate", value=True)
    show_sentiment = st.checkbox("Sentiment Analysis", value=True)
    show_trends = st.checkbox("Trend Analysis", value=True)
    
    # Refresh button
    st.markdown("---")
    if st.button("🔄 Refresh Data", use_container_width=True):
        st.rerun()
    
    # Auto-refresh
    auto_refresh = st.checkbox("⚡ Auto-refresh (30s)", value=False)
    if auto_refresh:
        import time
        time.sleep(30)
        st.rerun()

# Generate sample data (replace with your real data source)
@st.cache_data(ttl=300)
def load_dashboard_data():
    """Load dashboard metrics - replace with your actual data source"""
    np.random.seed(42)
    
    # Sample metrics
    data = {
        'total_calls': np.random.randint(800, 1200),
        'quality_score': np.random.uniform(75, 95),
        'compliance_rate': np.random.uniform(85, 98),
        'avg_sentiment': np.random.uniform(0.6, 0.9),
        'escalation_rate': np.random.uniform(5, 15),
        'resolution_rate': np.random.uniform(80, 95),
    }
    
    # Trend data
    dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
    trends = pd.DataFrame({
        'date': dates,
        'quality_score': np.random.uniform(70, 95, 30) + np.linspace(0, 10, 30),
        'calls': np.random.randint(20, 50, 30),
        'compliance': np.random.uniform(85, 98, 30),
    })
    
    return data, trends

# Load data
data, trends = load_dashboard_data()

# === TOP METRICS ROW ===
st.markdown("## 📈 Key Performance Indicators")

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        "📞 Total Calls",
        f"{data['total_calls']:,}",
        delta="+12.5%",
        help="Total calls processed in selected period"
    )

with col2:
    st.metric(
        "⭐ Quality Score",
        f"{data['quality_score']:.1f}%",
        delta="+2.3%",
        help="Average quality score across all interactions"
    )

with col3:
    st.metric(
        "✅ Compliance",
        f"{data['compliance_rate']:.1f}%",
        delta="+0.8%",
        help="Compliance rate with quality standards"
    )

with col4:
    st.metric(
        "😊 Sentiment",
        f"{data['avg_sentiment']:.2f}",
        delta="+0.05",
        help="Average customer sentiment score"
    )

st.markdown("---")

# === CHARTS ROW ===
col1, col2 = st.columns(2)

with col1:
    # Quality Trend Chart
    st.markdown("### 📊 Quality Score Trend")
    
    fig_quality = go.Figure()
    
    fig_quality.add_trace(go.Scatter(
        x=trends['date'],
        y=trends['quality_score'],
        mode='lines+markers',
        name='Quality Score',
        line=dict(color='#00f5ff', width=3),
        fill='tozeroy',
        fillcolor='rgba(0, 245, 255, 0.2)',
        marker=dict(size=8, color='#00f5ff', line=dict(color='white', width=2))
    ))
    
    fig_quality.add_hline(
        y=85, 
        line_dash="dash", 
        line_color="red",
        annotation_text="Target: 85%",
        annotation_position="right"
    )
    
    fig_quality.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white'),
        xaxis=dict(gridcolor='rgba(255,255,255,0.1)'),
        yaxis=dict(gridcolor='rgba(255,255,255,0.1)', range=[60, 100]),
        height=350,
        margin=dict(l=0, r=0, t=0, b=0)
    )
    
    st.plotly_chart(fig_quality, use_container_width=True)

with col2:
    # Call Volume Chart
    st.markdown("### 📞 Daily Call Volume")
    
    fig_calls = go.Figure()
    
    fig_calls.add_trace(go.Bar(
        x=trends['date'],
        y=trends['calls'],
        name='Calls',
        marker=dict(
            color=trends['calls'],
            colorscale='Viridis',
            showscale=True,
            colorbar=dict(title="Calls")
        )
    ))
    
    fig_calls.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white'),
        xaxis=dict(gridcolor='rgba(255,255,255,0.1)'),
        yaxis=dict(gridcolor='rgba(255,255,255,0.1)'),
        height=350,
        margin=dict(l=0, r=0, t=0, b=0)
    )
    
    st.plotly_chart(fig_calls, use_container_width=True)

st.markdown("---")

# === PERFORMANCE BREAKDOWN ===
st.markdown("## 🎯 Performance Breakdown")

col1, col2, col3 = st.columns(3)

with col1:
    # Gauge chart for Quality
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=data['quality_score'],
        delta={'reference': 85, 'increasing': {'color': "#00f5ff"}},
        title={'text': "Quality Score", 'font': {'color': 'white'}},
        gauge={
            'axis': {'range': [0, 100], 'tickcolor': 'white'},
            'bar': {'color': "#00f5ff"},
            'bgcolor': 'rgba(255,255,255,0.1)',
            'bordercolor': 'white',
            'steps': [
                {'range': [0, 60], 'color': 'rgba(255,0,0,0.3)'},
                {'range': [60, 85], 'color': 'rgba(255,255,0,0.3)'},
                {'range': [85, 100], 'color': 'rgba(0,255,0,0.3)'}
            ],
            'threshold': {
                'line': {'color': 'white', 'width': 4},
                'thickness': 0.75,
                'value': 85
            }
        }
    ))
    
    fig_gauge.update_layout(
        paper_bgcolor='rgba(0,0,0,0)',
        font={'color': 'white'},
        height=250
    )
    
    st.plotly_chart(fig_gauge, use_container_width=True)

with col2:
    # Compliance gauge
    fig_compliance = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=data['compliance_rate'],
        delta={'reference': 95, 'increasing': {'color': "#ff00ff"}},
        title={'text': "Compliance Rate", 'font': {'color': 'white'}},
        gauge={
            'axis': {'range': [0, 100], 'tickcolor': 'white'},
            'bar': {'color': "#ff00ff"},
            'bgcolor': 'rgba(255,255,255,0.1)',
            'bordercolor': 'white',
            'steps': [
                {'range': [0, 80], 'color': 'rgba(255,0,0,0.3)'},
                {'range': [80, 95], 'color': 'rgba(255,255,0,0.3)'},
                {'range': [95, 100], 'color': 'rgba(0,255,0,0.3)'}
            ]
        }
    ))
    
    fig_compliance.update_layout(
        paper_bgcolor='rgba(0,0,0,0)',
        font={'color': 'white'},
        height=250
    )
    
    st.plotly_chart(fig_compliance, use_container_width=True)

with col3:
    # Resolution rate gauge
    fig_resolution = go.Figure(go.Indicator(
        mode="gauge+number",
        value=data['resolution_rate'],
        title={'text': "Resolution Rate", 'font': {'color': 'white'}},
        gauge={
            'axis': {'range': [0, 100], 'tickcolor': 'white'},
            'bar': {'color': "#00ff00"},
            'bgcolor': 'rgba(255,255,255,0.1)',
            'bordercolor': 'white'
        }
    ))
    
    fig_resolution.update_layout(
        paper_bgcolor='rgba(0,0,0,0)',
        font={'color': 'white'},
        height=250
    )
    
    st.plotly_chart(fig_resolution, use_container_width=True)

st.markdown("---")

# === AI INSIGHTS ===
st.markdown("## 🤖 AI-Powered Insights")

insights_col1, insights_col2 = st.columns(2)

with insights_col1:
    # Positive insights
    st.success("""
    **📈 Trending Upward**
    - Quality scores improved by 2.3% this week
    - Compliance rate exceeded target (98% vs 95%)
    - Customer sentiment showing positive trend
    """)
    
    st.info("""
    **💡 Optimization Opportunities**
    - Peak call times: 2-4 PM (prepare more agents)
    - Top performing agents: Available for training sessions
    - Script version A performing 15% better than B
    """)

with insights_col2:
    # Areas for improvement
    st.warning("""
    **⚠️ Attention Required**
    - Escalation rate slightly elevated (12% vs target 10%)
    - Average handle time increased by 30 seconds
    - 3 agents below quality threshold
    """)
    
    st.error("""
    **🚨 Critical Alerts**
    - Compliance violation detected in Campaign XYZ
    - System downtime: 15 minutes on Feb 22
    - Missing data for 2 agents today
    """)

st.markdown("---")

# === QUICK ACTIONS ===
st.markdown("## ⚡ Quick Actions")

action_col1, action_col2, action_col3, action_col4 = st.columns(4)

with action_col1:
    if st.button("📊 Generate Report", use_container_width=True):
        st.success("✅ Report generated successfully!")
        
with action_col2:
    if st.button("📧 Email Summary", use_container_width=True):
        st.success("✅ Summary sent to team!")

with action_col3:
    if st.button("🔔 Set Alert", use_container_width=True):
        st.success("✅ Alert configured!")

with action_col4:
    if st.button("💾 Export Data", use_container_width=True):
        # Create export data
        export_df = pd.DataFrame({
            'Metric': ['Total Calls', 'Quality Score', 'Compliance', 'Sentiment'],
            'Value': [data['total_calls'], f"{data['quality_score']:.1f}%", 
                     f"{data['compliance_rate']:.1f}%", f"{data['avg_sentiment']:.2f}"]
        })
        
        csv = export_df.to_csv(index=False)
        st.download_button(
            "📥 Download CSV",
            csv,
            f"dashboard_metrics_{datetime.now().strftime('%Y%m%d')}.csv",
            "text/csv"
        )

# Footer
st.markdown("---")
st.markdown("""
<p style='text-align: center; color: #666; font-size: 0.9rem;'>
Quality Intelligence Engine V3.0 • Last updated: {} • Auto-refresh: {}
</p>
""".format(
    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "ON" if auto_refresh else "OFF"
), unsafe_allow_html=True)
