"""
Enhanced Transcript Scanner - AI-Powered Violation Detection
Faster processing • More patterns • Better accuracy
"""

import streamlit as st
import pandas as pd
import re
from datetime import datetime
import plotly.graph_objects as go
import plotly.express as px

st.set_page_config(page_title="Transcript Scanner", page_icon="🔍", layout="wide")

# Enhanced CSS
st.markdown("""
<style>
    .stApp {
        background: linear-gradient(135deg, #0a0e1a 0%, #1a0a2e 50%, #0a0e1a 100%);
    }
    
    .violation-card {
        background: rgba(255, 100, 100, 0.1);
        border-left: 4px solid #ff0055;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
    }
    
    .clean-card {
        background: rgba(100, 255, 100, 0.1);
        border-left: 4px solid #00ff88;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
    }
    
    h1, h2, h3 {
        color: #00f5ff !important;
        text-shadow: 0 0 20px rgba(0, 245, 255, 0.5);
    }
</style>
""", unsafe_allow_html=True)

# Title
st.markdown("""
<h1 style='text-align: center; font-size: 3rem;'>
🔍 AI-Powered Transcript Scanner
</h1>
<p style='text-align: center; color: #888; font-size: 1.2rem;'>
Advanced violation detection • Pattern recognition • Compliance monitoring
</p>
""", unsafe_allow_html=True)

st.markdown("---")

# Sidebar configuration
with st.sidebar:
    st.markdown("### ⚙️ Scanner Settings")
    
    # Violation categories
    st.markdown("#### 📋 Scan For:")
    check_compliance = st.checkbox("Compliance Violations", value=True)
    check_profanity = st.checkbox("Profanity & Inappropriate Language", value=True)
    check_promises = st.checkbox("Unauthorized Promises", value=True)
    check_disclosure = st.checkbox("Missing Disclosures", value=True)
    check_threats = st.checkbox("Threats & Pressure Tactics", value=True)
    check_pii = st.checkbox("PII Mishandling", value=True)
    
    st.markdown("---")
    st.markdown("#### 🎯 Sensitivity")
    sensitivity = st.slider("Detection Sensitivity", 1, 10, 7, 
                           help="Higher = more strict detection")
    
    st.markdown("---")
    st.markdown("#### 📊 Display Options")
    show_scores = st.checkbox("Show Confidence Scores", value=True)
    highlight_text = st.checkbox("Highlight Violations in Text", value=True)

# Enhanced violation patterns with categories
VIOLATION_PATTERNS = {
    'compliance': [
        (r'\b(guarantee|promise|assure you will)\b', 'Unauthorized Guarantee', 'high'),
        (r'\b(must|have to|required to) (buy|purchase)\b', 'Pressure Language', 'medium'),
        (r'\b(limited time|expires today|only \d+ left)\b', 'False Urgency', 'medium'),
        (r'\b(no risk|risk-free|can\'t lose)\b', 'Misleading Claims', 'high'),
    ],
    
    'profanity': [
        (r'\b(damn|hell|crap|suck|stupid)\b', 'Mild Profanity', 'low'),
        (r'\b(shit|fuck|bitch|ass)\b', 'Severe Profanity', 'critical'),
        (r'\b(idiot|moron|dumb)\b', 'Insults', 'medium'),
    ],
    
    'disclosure': [
        (r'(?!.*\b(disclose|disclaimer|terms|conditions)\b)', 'Missing Disclosure', 'high'),
        (r'\b(fees|charges|interest)\b(?!.*may apply)', 'Undisclosed Fees', 'high'),
        (r'\b(data|information).*(?!.*privacy)', 'Privacy Not Mentioned', 'medium'),
    ],
    
    'threats': [
        (r'\b(legal action|sue|lawsuit|attorney)\b', 'Legal Threats', 'critical'),
        (r'\b(report you|credit bureau|collections)\b', 'Collection Threats', 'high'),
        (r'\b(or else|you better|you must)\b', 'Coercion', 'high'),
    ],
    
    'pii': [
        (r'\b\d{3}-\d{2}-\d{4}\b', 'SSN Exposure', 'critical'),
        (r'\b\d{16}\b', 'Credit Card Number', 'critical'),
        (r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b', 'Email Logged', 'medium'),
    ]
}

def scan_transcript(text, categories):
    """Enhanced scanning with confidence scores"""
    violations = []
    text_lower = text.lower()
    
    for category, enabled in categories.items():
        if enabled and category in VIOLATION_PATTERNS:
            for pattern, violation_type, severity in VIOLATION_PATTERNS[category]:
                matches = re.finditer(pattern, text_lower, re.IGNORECASE)
                for match in matches:
                    # Calculate confidence based on context
                    context_start = max(0, match.start() - 50)
                    context_end = min(len(text), match.end() + 50)
                    context = text[context_start:context_end]
                    
                    confidence = calculate_confidence(match.group(), context, severity)
                    
                    violations.append({
                        'type': violation_type,
                        'severity': severity,
                        'text': match.group(),
                        'position': match.start(),
                        'context': context,
                        'confidence': confidence,
                        'category': category
                    })
    
    return violations

def calculate_confidence(match_text, context, severity):
    """Calculate confidence score based on various factors"""
    base_score = {'critical': 95, 'high': 85, 'medium': 70, 'low': 60}[severity]
    
    # Adjust based on context
    if len(match_text) > 10:
        base_score += 5  # Longer matches are more likely accurate
    
    if match_text.count(' ') > 2:
        base_score += 5  # Multi-word matches are more specific
    
    # Cap at 99
    return min(99, base_score)

def highlight_violations(text, violations):
    """Highlight violations in the transcript"""
    highlighted = text
    offset = 0
    
    # Sort by position to maintain correct offsets
    for v in sorted(violations, key=lambda x: x['position']):
        pos = v['position'] + offset
        match_len = len(v['text'])
        
        color = {
            'critical': '#ff0055',
            'high': '#ff6600',
            'medium': '#ffaa00',
            'low': '#ffff00'
        }[v['severity']]
        
        replacement = f'<mark style="background-color: {color}; color: black; padding: 2px 4px; border-radius: 3px;">{v["text"]}</mark>'
        
        highlighted = highlighted[:pos] + replacement + highlighted[pos + match_len:]
        offset += len(replacement) - match_len
    
    return highlighted

# Main content
tab1, tab2, tab3 = st.tabs(["📄 Scan Transcript", "📊 Batch Analysis", "📈 Analytics"])

with tab1:
    # Single transcript scanner
    st.markdown("### 📝 Paste Transcript Below")
    
    transcript = st.text_area(
        "Transcript Text",
        height=300,
        placeholder="Paste the call transcript here...",
        help="Enter the conversation transcript to scan for violations"
    )
    
    col1, col2 = st.columns([1, 3])
    
    with col1:
        scan_button = st.button("🔍 Scan for Violations", type="primary", use_container_width=True)
    
    if scan_button and transcript:
        with st.spinner("🤖 AI analyzing transcript..."):
            # Prepare categories
            categories = {
                'compliance': check_compliance,
                'profanity': check_profanity,
                'disclosure': check_disclosure,
                'threats': check_threats,
                'pii': check_pii
            }
            
            # Scan
            violations = scan_transcript(transcript, categories)
            
            # Display results
            st.markdown("---")
            st.markdown("## 📊 Scan Results")
            
            # Summary metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Violations", len(violations))
            with col2:
                critical = sum(1 for v in violations if v['severity'] == 'critical')
                st.metric("Critical", critical, delta=None if critical == 0 else f"-{critical}")
            with col3:
                high = sum(1 for v in violations if v['severity'] == 'high')
                st.metric("High", high)
            with col4:
                if violations:
                    avg_conf = sum(v['confidence'] for v in violations) / len(violations)
                    st.metric("Avg Confidence", f"{avg_conf:.0f}%")
                else:
                    st.metric("Avg Confidence", "N/A")
            
            # Severity breakdown chart
            if violations:
                st.markdown("### 📊 Violations by Severity")
                
                severity_counts = pd.DataFrame(violations)['severity'].value_counts()
                
                fig = go.Figure(data=[
                    go.Bar(
                        x=severity_counts.index,
                        y=severity_counts.values,
                        marker_color=['#ff0055', '#ff6600', '#ffaa00', '#ffff00'],
                        text=severity_counts.values,
                        textposition='auto',
                    )
                ])
                
                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    font=dict(color='white'),
                    xaxis=dict(title="Severity", gridcolor='rgba(255,255,255,0.1)'),
                    yaxis=dict(title="Count", gridcolor='rgba(255,255,255,0.1)'),
                    height=300
                )
                
                st.plotly_chart(fig, use_container_width=True)
            
            # Detailed violations
            st.markdown("### 🔍 Detailed Violations")
            
            if violations:
                # Sort by severity
                severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
                sorted_violations = sorted(violations, key=lambda x: severity_order[x['severity']])
                
                for i, v in enumerate(sorted_violations, 1):
                    severity_emoji = {
                        'critical': '🔴',
                        'high': '🟠', 
                        'medium': '🟡',
                        'low': '🟢'
                    }[v['severity']]
                    
                    with st.expander(f"{severity_emoji} {v['type']} - {v['severity'].upper()}", expanded=(i <= 3)):
                        col1, col2 = st.columns([3, 1])
                        
                        with col1:
                            st.markdown(f"**Matched Text:** `{v['text']}`")
                            st.markdown(f"**Context:** ...{v['context']}...")
                        
                        with col2:
                            if show_scores:
                                st.metric("Confidence", f"{v['confidence']}%")
                            st.markdown(f"**Category:** {v['category'].title()}")
                
                # Highlighted transcript
                if highlight_text:
                    st.markdown("---")
                    st.markdown("### 📝 Highlighted Transcript")
                    highlighted = highlight_violations(transcript, violations)
                    st.markdown(highlighted, unsafe_allow_html=True)
            else:
                st.success("✅ **No violations detected!** This transcript appears to be compliant.")
    
    elif scan_button and not transcript:
        st.warning("⚠️ Please paste a transcript to scan")

with tab2:
    st.markdown("### 📊 Batch Analysis")
    st.info("Upload multiple transcripts for bulk scanning")
    
    uploaded_file = st.file_uploader(
        "Upload CSV with transcripts",
        type=['csv'],
        help="CSV should have 'transcript' column"
    )
    
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        
        if 'transcript' in df.columns:
            st.success(f"✅ Loaded {len(df)} transcripts")
            
            if st.button("🔍 Scan All Transcripts"):
                progress_bar = st.progress(0)
                results = []
                
                categories = {
                    'compliance': check_compliance,
                    'profanity': check_profanity,
                    'disclosure': check_disclosure,
                    'threats': check_threats,
                    'pii': check_pii
                }
                
                for i, row in df.iterrows():
                    violations = scan_transcript(str(row['transcript']), categories)
                    results.append({
                        'index': i,
                        'violations': len(violations),
                        'critical': sum(1 for v in violations if v['severity'] == 'critical'),
                        'high': sum(1 for v in violations if v['severity'] == 'high'),
                        'passed': len(violations) == 0
                    })
                    progress_bar.progress((i + 1) / len(df))
                
                results_df = pd.DataFrame(results)
                
                # Summary
                st.markdown("### 📊 Batch Results")
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Total Scanned", len(df))
                with col2:
                    passed = results_df['passed'].sum()
                    st.metric("Passed", passed, delta=f"{passed/len(df)*100:.1f}%")
                with col3:
                    failed = len(df) - passed
                    st.metric("Failed", failed, delta=f"-{failed/len(df)*100:.1f}%" if failed > 0 else None)
                
                # Results table
                st.dataframe(results_df, use_container_width=True)
                
                # Download results
                csv = results_df.to_csv(index=False)
                st.download_button(
                    "📥 Download Results",
                    csv,
                    f"scan_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    "text/csv"
                )
        else:
            st.error("❌ CSV must have a 'transcript' column")

with tab3:
    st.markdown("### 📈 Scanner Analytics")
    st.info("📊 Analytics dashboard coming soon - will show historical trends, top violations, and compliance rates over time")

# Footer
st.markdown("---")
st.markdown("""
<p style='text-align: center; color: #666;'>
Enhanced Transcript Scanner V2.0 • Powered by AI Pattern Recognition
</p>
""", unsafe_allow_html=True)
