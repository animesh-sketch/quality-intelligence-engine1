import React from 'react';
import SalesIntelligenceDashboard from './Dashboard';
import './index.css';

function App() {
  return <SalesIntelligenceDashboard />;
}

export default App;
